<?php


namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CustomerPayment extends Model
{
    protected $table='customerpayment';
    protected $primaryKey = 'id';
}
