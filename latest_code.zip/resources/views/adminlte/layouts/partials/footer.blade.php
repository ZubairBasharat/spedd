<!-- Main Footer -->

<footer class="main-footer">

    <!-- To the right -->

    <div class="pull-right hidden-xs">

        <!-- <a href="http://technicalctrl.com"><b>Speed</b></a>. -->

    </div>

    <!-- Default to the left -->

    <strong>Copyright &copy; 2021 <a href="https://app.speeds.ws"> Powered by Speed.</a>







</footer>

