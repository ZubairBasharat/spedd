Click here to reset your password: {{ route('password/reset/'.$token) }}
