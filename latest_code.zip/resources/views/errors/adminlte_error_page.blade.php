@extends('adminlte.layouts.app')

@section('htmlheader_title')
@endsection
@section('main-content')
  <div class="row">
      <div class="alert alert-danger">
        <span><i class="fa fa-bell-o"></i>This page is not responding.</span>
      </div>
  </div>
@endsection

