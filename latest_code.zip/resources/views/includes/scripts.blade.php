
<script src="{{URL::to('assets/js/chosen.jquery.min.js')}}"></script>

