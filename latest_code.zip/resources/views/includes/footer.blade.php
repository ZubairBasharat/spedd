<script>

    

    $(document).ready(function()
    {

        $('.select2').chosen({

            width: '100%'

        });



    } );

    

</script>



