@extends('layouts.app')

@section('body')
<br>
<br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"> <b>Thank you for registering.</b></div>
                <div class="panel-body">
                    The app is under development and you will be notified once its ready.

                </div>
            </div>
        </div>
    </div>
</div>

@endsection
