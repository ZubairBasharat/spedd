<?php $__env->startSection('htmlheader_title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-styles'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>
  <div class="row">
    <div class="col-md-7">
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">
            Restaurant Information
          </h3>
        </div>
        <div class="box-body">
          <table class="table table-bordered">
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.restaurant_name'); ?></th>
              <td><?php echo e($data->name); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.restaurant_type'); ?></th>
              <td><?php echo e($data->restaurant_type); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.min_distance'); ?></th>
              <td><?php echo e($data->mini_distance); ?> KM</td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.min_distance_charges'); ?></th>
              <td>SAR <?php echo e($data->mini_distance_charges); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.charges'); ?></th>
              <td>SAR <?php echo e($data->charges_per_km); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.location'); ?></th>
              <td><?php echo e($data->restaurant_location); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.latitude'); ?></th>
              <td><?php echo e($data->latitude); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.longitude'); ?></th>
              <td><?php echo e($data->longitude); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.region'); ?></th>
              <td><?php echo e($data->region); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.city'); ?></th>
              <td><?php echo e($data->city); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.commercial_reg_no'); ?></th>
              <td><?php echo e($data->commercial_reg_no); ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="box box-primary" style="margin-bottom: 5px;">
        <div class="box-header">
          <h3 class="box-title">Sales Statistics</h3>
        </div>
        <div class="box-body " style="padding: 0;">
          <table class="table">
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.total_orders'); ?></th>
              <td><?php echo e($sales->total_orders); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.grand_total'); ?></th>
              <td><?php echo e(($sales->grand_total == null)? '--': 'SAR ' . $sales->grand_total); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.order_amount'); ?></th>
              <td><?php echo e(($sales->order_amount == null)? '--': 'SAR '. $sales->order_amount); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.delivery_fee'); ?></th>
              <td><?php echo e(($sales->delivery_fee == null)? '--': 'SAR '. $sales->delivery_fee); ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="box box-danger" style="margin-bottom: 5px;">
        <div class="box-header">
          <h3 class="box-title">Account Information</h3>
        </div>
        <div class="box-body " style="padding: 0;">
          <table class="table">
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.username'); ?></th>
              <td><?php echo e($data->username); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.email'); ?></th>
              <td><?php echo e($data->email); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.email_status'); ?></th>
              <td><?php echo e(($data->verified == 1)? 'Verified': 'Unverified'); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.account_status'); ?></th>
              <td><?php echo e(($data->active == 1)? 'Active': 'Inactive'); ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="box box-info">
        <div class="box-header">
          <h3 class="box-title">Contact Information</h3>
        </div>
        <div class="box-body">
          <table class="table table-bordered">
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.phone_number'); ?></th>
              <td><?php echo e($data->phone_number); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.store_manager_name'); ?></th>
              <td><?php echo e($data->store_manager_name); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.store_manager_number'); ?></th>
              <td><?php echo e($data->store_manager_number); ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-body table-responsive">
          
        </div>
      </div>
    </div>
  </div> -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>

  <script type="text/javascript">
      $(document).ready(function() {

      });
  </script>


  
<?php $__env->stopPush(); ?>


<?php echo $__env->make('adminlte.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>