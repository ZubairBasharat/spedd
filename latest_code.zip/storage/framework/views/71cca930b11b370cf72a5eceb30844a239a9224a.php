<!-- Left side column. contains the logo and sidebar -->

<aside class="main-sidebar">



    <!-- sidebar: style can be found in sidebar.less -->

    <section class="sidebar">



        <!-- Sidebar user panel (optional) -->

        <?php if(! Auth::guest()): ?>



            <div class="user-panel">

                <div class="pull-left image">

                    <?php if(auth()->user()->profile_picture != null): ?>


                        <img src="<?php echo e(auth()->user()->profile_picture); ?>" class="img-circle"  />

                    <?php else: ?>

                        <img src="<?php echo e(URL::to('/usersimages/avatar.jpg')); ?>" class="img-circle" alt="User Image" />

                    <?php endif; ?>

                </div>

                <div class="pull-left info">

                    <p><?php echo e(Auth::user()->name); ?></p>

                    <!-- Status -->
                    <?php $usertype = "";?>
                    <?php if(auth()->user()->isAdmin == 1): ?>
                        <?php $usertype = "Super Admin";?>
                    <?php elseif(auth()->user()->user_type == 2): ?>
                        <?php $usertype = "Restaurant";?>
                    <?php elseif(auth()->user()->user_type == 4): ?>
                        <?php $usertype = "Sub Admin | Region";?>
                    <?php elseif(auth()->user()->user_type == 5): ?>
                        <?php $usertype = "Sub Admin | Restaurant";?>
                    <?php endif; ?>

                    <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e($usertype); ?> </a>
                </div>

            </div>

        <?php endif; ?>

        <!-- Sidebar Menu -->

        <ul class="sidebar-menu">

            <li class="header"> <?php echo app('translator')->getFromJson('adminlte.main_navigation'); ?>  </li>

            <?php $visible = false;?>

            <!-- Optionally, you can add icons to the links -->

            <li class="<?php echo e((request()->is('user/profile*')) ? 'active' : ''); ?>"><a href="<?php echo e(url('home')); ?>"><i class='fa fa-home'></i> <span> <?php echo app('translator')->getFromJson('adminlte.dashboard'); ?> </span></a></li>

            <!-- <li><a href="#"><i class='fa fa-link'></i> <span>Menu 1</span></a></li> -->

            <?php if(auth()->user() != null): ?>
                <?php if(auth()->user()->user_type == 2): ?>
                    <li class="<?php echo e((request()->is('make/order*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('make_order')); ?>"><i class='fa fa-first-order'></i> <span> <?php echo app('translator')->getFromJson('adminlte.make_order'); ?> </span></a></li>
                <?php endif; ?>
            <?php endif; ?>

            <li class="<?php echo e((request()->is('orders/dashboard*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('orders_dashboard')); ?>"><i class='fa fa-tachometer'></i> <span> <?php echo app('translator')->getFromJson('adminlte.orders'); ?> </span></a></li>

            <li class="<?php echo e((request()->is('sale/report*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('sales_report')); ?>"><i class='fa fa-exchange'></i> <span> <?php echo app('translator')->getFromJson('adminlte.sales_report'); ?> </span></a></li>


            <?php if(auth()->user() != null): ?>
                <?php if(auth()->user()->user_type == 1 || auth()->user()->user_type == 4): ?>

                    <li class="<?php echo e((request()->is('admin/manage/restaurant*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manage_restaurants')); ?>"><i class='fa fa-building'></i> <span>  <?php echo app('translator')->getFromJson('adminlte.restaurants'); ?> </span></a></li>

                    <li class="<?php echo e((request()->is('admin/manage/driver*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manage_drivers')); ?>"><i class='fa fa-users'></i> <span>  <?php echo app('translator')->getFromJson('adminlte.drivers'); ?> </span></a></li>



                    <?php if(auth()->user()->user_type == 1): ?>
                        <li class="<?php echo e((request()->is('manage/finance*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manage_finance_settings')); ?>"><i class='fa fa-bar-chart'></i> <span> <?php echo app('translator')->getFromJson('adminlte.finance_settings'); ?> </span></a></li>

                        <li class="<?php echo e((request()->is('manage/sub_admins*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manage_subadmins')); ?>"><i class='fa fa-legal'></i> <span> <?php echo app('translator')->getFromJson('adminlte.sub_admin'); ?> | <?php echo app('translator')->getFromJson('adminlte.region'); ?> </span></a></li>

                        <li class="<?php echo e((request()->is('manage/subadmin/restaurant*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('manage_restaurant_subadmins')); ?>"><i class='fa fa-legal'></i> <span> <?php echo app('translator')->getFromJson('adminlte.sub_admin'); ?> | <?php echo app('translator')->getFromJson('adminlte.restaurant'); ?> </span></a></li>


                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>

        </ul><!-- /.sidebar-menu -->

    </section>

    <!-- /.sidebar -->

</aside>

