<?php $__env->startSection('htmlheader_title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

	  <div class="box">

      <div class="box-header">
      </div>

      <div class="box-body">
        <div class="row">
          <?php if(session('status')): ?>
            <div class="alert alert-success">
              <?php echo e(session('status')); ?>

            </div>
          <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>
        </div>
        <div class="row">
          <div class="col-md-12">
            <a style="margin: 15px 5px;" href="<?php echo e(route('add_restaurant')); ?>" class="pull-right btn btn-success"><i title="Add Restaurant" class=" fa fa-plus"></i> &nbsp; <?php echo app('translator')->getFromJson('adminlte.add_restaurant'); ?> </a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="table-responsive">
              <table id="mydatatable" class="table table-bordered table-striped">

                <thead>

                  <tr>

                    <th><?php echo app('translator')->getFromJson('adminlte.restaurant_name'); ?> </th>

                    <th><?php echo app('translator')->getFromJson('adminlte.restaurant_type'); ?> </th>

                    <th><?php echo app('translator')->getFromJson('adminlte.location'); ?> </th>

                    <th><?php echo app('translator')->getFromJson('adminlte.region'); ?> </th>

                    <th><?php echo app('translator')->getFromJson('adminlte.city'); ?> </th>

                    <th><?php echo app('translator')->getFromJson('adminlte.username'); ?></th>

                    <th><?php echo app('translator')->getFromJson('adminlte.email'); ?></th>

                    <th><?php echo app('translator')->getFromJson('adminlte.email_status'); ?></th> <!-- email is verified or not -->

                    <th><?php echo app('translator')->getFromJson('adminlte.account_status'); ?></th> <!-- account is activated or not, two cases 1) email is not verified 2) user is soft deleted -->

                    <!-- <th>Created At</th> -->

                    <th><?php echo app('translator')->getFromJson('adminlte.actions'); ?></th>

                  </tr>

                </thead>

                <tbody>

                  <?php if(count($users) > 0): ?>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>

                        <td>
                          <a href="<?php echo e(route('restaurant_details', encrypt($u->id))); ?>" target="_blank"> <?php echo e($u->name); ?> </a>
                        </td>

                        <td><?php echo e($u->restaurant_type); ?> </td>
                        <td><?php echo e($u->restaurant_location); ?> </td>
                        <td><?php echo e($u->region); ?> </td>
                        <td><?php echo e($u->city); ?> </td>
                        <td><?php echo e($u->username); ?></td>
                        <td><?php echo e($u->email); ?></td>

                        <td>

                          <?php if($u->verified == 1): ?>

                            <span class="label label-success">

                              Verified

                            </span>

                          <?php else: ?>

                            <span class="label label-danger">

                              Unverified

                            </span>

                          <?php endif; ?>

                        </td>

                        <td>

                          <?php if($u->active == 1): ?>

                            <span class="label label-success">

                              Active

                            </span>

                          <?php else: ?>

                            <span class="label label-danger">

                              Disabled

                            </span>

                          <?php endif; ?>

                        </td>

                        <!-- <td><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($u->created_at))->diffForHumans()); ?></td> -->

                        <td>
                          <?php if(auth()->user()->user_type == 1): ?>
                            <a href="<?php echo e(route('edit_restaurant', encrypt($u->id))); ?>"> <span class="label label-info"> <?php echo app('translator')->getFromJson('adminlte.update'); ?> </span></a>
                            &nbsp;
                            <a href="#" onclick='LinksModal( <?php echo e($u->id); ?> )'> <span class="label label-warning"> <?php echo app('translator')->getFromJson('adminlte.account_setting'); ?> </span></a>
                          <?php else: ?>
                            &nbsp;
                          <?php endif; ?>
                        </td>

                      </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php else: ?>

                    <tr>

                      <td colspan="10">No restaurant exists in db.</td>

                    </tr>

                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="updateModal">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Manage Restaurant</h4>
          </div>
          <div class="modal-body" id="model_body">
          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
  <script type="text/javascript">
    function LinksModal(user_id)
    {
      var data= {'user_id':user_id, '_token':'<?php echo e(csrf_token()); ?>' };

      $.post('<?php echo e(route('edit_account_status_modal')); ?>', data , function(response) {

          $("#model_body").html(response);
          $('#updateModal').modal('show');
      });
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('adminlte.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>