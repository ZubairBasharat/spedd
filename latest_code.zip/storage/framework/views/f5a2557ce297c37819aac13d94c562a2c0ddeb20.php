<?php $__env->startSection('htmlheader_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>

	  <div class="box">
        <div class="row">
          <?php if(session('status')): ?>

              <div class="alert alert-success">

                  <?php echo e(session('status')); ?>


              </div>
          <?php endif; ?>
          <?php if(count($errors) > 0): ?>

              <div class="alert alert-danger">

                  <ul>

                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <li><?php echo e($error); ?></li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </ul>

              </div>
          <?php endif; ?>

      </div>
      <div class="box-body">

        <form form="horizontal" action="<?php echo e(route('manage_finance_settings_post')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="id" value="<?php echo e(encrypt($data->id)); ?>">
          <div class="row">
            <div class="form-group col-md-6">
                <label for="email_status" class="control-label"><?php echo app('translator')->getFromJson('adminlte.currency'); ?></label>
                <input type="text" class="form-control" name="currency" value="<?php echo e($data->currency); ?>" required="">
            </div>

            <div class="form-group col-md-6">
              <label for="active" class="control-label"><?php echo app('translator')->getFromJson('adminlte.tax_on_restaurant_order'); ?></label>
              <input type="text" class="form-control" name="tax_on_restaurant_order" value="<?php echo e($data->tax_on_restaurant_order); ?>" required="">
            </div>
          </div>
          <div class="row">
            <div class="form-group col-md-6">
                <label for="email_status" class="control-label"><?php echo app('translator')->getFromJson('adminlte.min_distance'); ?></label>
                <input type="text" class="form-control" name="mini_distance" value="<?php echo e($data->mini_distance); ?>" required="">
            </div>

            <div class="form-group col-md-6">
              <label for="active" class="control-label"><?php echo app('translator')->getFromJson('adminlte.min_distance_charges'); ?></label>
              <input type="text" class="form-control" name="mini_distance_charges" value="<?php echo e($data->mini_distance_charges); ?>" required="">
            </div>
          </div>
          <div class="row">
            <div class="form-group col-md-6">
                <label for="email_status" class="control-label"><?php echo app('translator')->getFromJson('adminlte.charges'); ?></label>
                <input type="text" class="form-control" name="charges_per_km" value="<?php echo e($data->charges_per_km); ?>" required="">
            </div>

            <div class="form-group col-md-6">
              <label for="active" class="control-label"><?php echo app('translator')->getFromJson('adminlte.driver_subscription_fee'); ?></label>
              <input type="text" class="form-control" name="driver_subscription_fee" value="<?php echo e($data->driver_subscription_fee); ?>" required="">
            </div>
          </div>
          <div class="row">
            <div class="form-group col-md-6">
                <label for="email_status" class="control-label"><?php echo app('translator')->getFromJson('adminlte.delivery_fee'); ?></label>
                <input type="text" class="form-control" name="delivery_fee" value="<?php echo e($data->delivery_fee); ?>" required="">
            </div>
            <div class="form-group col-md-6">
                <label for="max_due_amount" class="control-label">Maximum Due Amount</label>
                <input type="text" class="form-control" name="max_due_amount" value="<?php echo e($data->max_due_amount); ?>" required="">
            </div>

          </div>
          <div class="row">
            <div class="form-group col-md-12">
                <label for="submit" class="control-label">&nbsp;</label>
                <input type="submit" class="btn btn-primary pull-right my-2" value="<?php echo app('translator')->getFromJson('adminlte.update'); ?>">
            </div>
          </div>

        </form>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
  <script type="text/javascript">

  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('adminlte.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>