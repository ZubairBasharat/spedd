<?php $__env->startSection('htmlheader_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('plugin-style'); ?>
  <style type="text/css">
    .select2-default {
      color: #999 !important;
      width: auto !important;
    }
  </style>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="box">
      <div class="box-header">
        <h3 class="box-title"><?php echo app('translator')->getFromJson('adminlte.search_parameters'); ?></h3>
      </div>
      <?php if(session('status')): ?>
          <div class="alert alert-success">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
      <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      <?php endif; ?>

      <div class="box-body">
        <form action="<?php echo e(route('sales_report_post')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <div class="row">
            <div class="form-group col-sm-6">
              <label for="from_date"><?php echo app('translator')->getFromJson('adminlte.from_date'); ?></label>
              <input type="date" class="form-control" id="from_date" name="from_date" >
            </div>

            <div class="form-group col-sm-6">
              <label for="to_date"><?php echo app('translator')->getFromJson('adminlte.to_date'); ?></label>
              <input type="date" class="form-control" id="to_date" name="to_date">
            </div>
          </div>
          <div class="row">
            <!-- <div class="form-group col-sm-6">
              <label for="region">Region </label>
              <select class="form-control select2" id="region" name="region[]" multiple="">
                <?php if(isset($regions)): ?>
                  <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($region); ?>"> <?php echo e($region); ?> </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
            </div> -->
            <?php if($restaurants != null): ?>
              <div class="form-group col-sm-12">
                <label for="restaurant"><?php echo app('translator')->getFromJson('adminlte.restaurant'); ?> </label>
                <select style="width: 100%" class="form-control select2" id="restaurant" name="restaurant[]" multiple="">
                    <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($restaurant->id); ?>"> <?php echo e($restaurant->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            <?php endif; ?>

          </div>
          <div class="row">
            <div class="col-sm-12">
              <input type="submit" name="submit" value="<?php echo app('translator')->getFromJson('adminlte.generate_report'); ?>" class="btn btn-success pull-right">
            </div>
          </div>

        </form>
      </div>
    </div>

    <?php if(isset($data)): ?>
      <div class="box">
        <div class="box-header">
          <h3 class="box-title"><?php echo app('translator')->getFromJson('adminlte.report_generated'); ?> <br><br>
            <small> <?php echo app('translator')->getFromJson('adminlte.from_date'); ?>:
              <span style="color: blue;"><?php echo e(date("d-m-Y",strtotime($minDate))); ?></span>
            </small> &nbsp;
            <small> <?php echo app('translator')->getFromJson('adminlte.to_date'); ?>:
              <span style="color: green;"><?php echo e(date("d-m-Y",strtotime($maxDate))); ?> </span>
            </small>
          </h3>
        </div>

        <div class="box-body">
          <div class="table-responsive">
            <table id="mydatatable" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <!-- if not restaurant show name -->
                  <?php if(auth()->user()->user_type != 2): ?>
                    <th><?php echo app('translator')->getFromJson('adminlte.restaurant_name'); ?> </th>
                  <?php endif; ?>

                  <th><?php echo app('translator')->getFromJson('adminlte.region'); ?></th>

                  <th><?php echo app('translator')->getFromJson('adminlte.total_orders'); ?></th>

                  <th><?php echo app('translator')->getFromJson('adminlte.total_sale'); ?></th>

                  <th><?php echo app('translator')->getFromJson('adminlte.total_order_amount'); ?> </th>

                  <th><?php echo app('translator')->getFromJson('adminlte.total_delivery_fee'); ?></th>
                </tr>
              </thead>
              <tbody>
                <?php if(count($data) > 0): ?>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <!-- if not restaurant show name -->
                      <?php if(auth()->user()->user_type != 2): ?>
                        <td><?php echo e($u->name); ?> </td>
                      <?php endif; ?>
                      <td><?php echo e($u->region); ?></td>
                      <td><?php echo e($u->total_orders); ?></td>
                      <td><?php echo e($u->grand_total); ?></td>
                      <td><?php echo e($u->order_amount); ?></td>
                      <td><?php echo e($u->delivery_fee); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <tr>
                    <td colspan="5">No details has been found.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>