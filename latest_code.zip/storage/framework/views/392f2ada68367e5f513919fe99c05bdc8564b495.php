<?php $__env->startSection('htmlheader_title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-style'); ?>
  <style type="text/css">
    .select2-search__field{
      width: 100%;
    }
  </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>

  <div class="box">
    <div class="box-header">
    </div>
    <div class="box-body">
      <div class="row">
        <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>
      </div>
      <div class="col-md-12">
        <a style="margin: 10px 20px;" href="#" data-toggle="modal" data-target="#newModal" class="pull-right btn btn-success"><i title="Add Sub-Admin" class=" fa fa-plus"></i> &nbsp; <?php echo app('translator')->getFromJson('adminlte.add_subadmin'); ?> </a>
      </div>
      <div class="col-md-12">
        <table id="mydatatable" class="table table-bordered table-striped">
          <thead>

            <tr>

              <th><?php echo app('translator')->getFromJson('adminlte.name'); ?> </th>

              <th><?php echo app('translator')->getFromJson('adminlte.username'); ?></th>

              <th><?php echo app('translator')->getFromJson('adminlte.email'); ?></th>

              <th><?php echo app('translator')->getFromJson('adminlte.restaurants'); ?></th>

              <th><?php echo app('translator')->getFromJson('adminlte.email_status'); ?></th>

              <th><?php echo app('translator')->getFromJson('adminlte.account_status'); ?></th>

              <th><?php echo app('translator')->getFromJson('adminlte.actions'); ?></th>

            </tr>

          </thead>

          <tbody>
            <?php if(count($users) > 0): ?>

              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>

                  <td><?php echo e($u->name); ?> </td>

                  <td><?php echo e($u->username); ?></td>

                  <td><?php echo e($u->email); ?></td>
                  <td>
                    <?php if(isset($u->restaurants)): ?>
                      <?php if(count($u->restaurants) > 0): ?>
                        <ol>
                          <?php $__currentLoopData = $u->restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($rest->name); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                      <?php else: ?>
                        No restaurant selected
                      <?php endif; ?>
                    <?php else: ?>
                      No restaurant selected
                    <?php endif; ?>
                  </td>

                  <td>

                    <?php if($u->verified == 1): ?>

                      <span class="label label-success">

                        Verified

                      </span>

                    <?php else: ?>

                      <span class="label label-danger">

                        Unverified

                      </span>

                    <?php endif; ?>

                  </td>

                  <td>

                    <?php if($u->active == 1): ?>

                      <span class="label label-success">

                        Active

                      </span>

                    <?php else: ?>

                      <span class="label label-danger">

                        Disabled

                      </span>

                    <?php endif; ?>

                  </td>

                  <td><a href="#" onclick='LinksModal( <?php echo e($u->id); ?> )'> <span class="label label-info"> <?php echo app('translator')->getFromJson('adminlte.update'); ?> </span></a></td>

                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

              <tr>

                <td colspan="7">No restaurant-subadmin exists in db.</td>

              </tr>

            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" id="newModal">
    <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">

              <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                  <span aria-hidden="true">&times;</span>

                  <span class="sr-only">Close</span>

              </button>

              <h5 class="modal-title"><?php echo app('translator')->getFromJson('adminlte.add_subadmin'); ?> | <?php echo app('translator')->getFromJson('adminlte.restaurant'); ?></h5>

          </div>

          <div class="modal-body">

              <div class="row sameheight-container">

                  <div class="col-md-12">

                      <div class="card card-block sameheight-item" >

                          <form class="" role="form" action="<?php echo e(route('add_restaurant_subadmin')); ?>" method="POST" enctype="multipart/form-data">

                              <?php echo e(csrf_field()); ?>


                              <div class="row">
                                  <div class="col-md-12 form-group">
                                      <label class="" for="project"><?php echo app('translator')->getFromJson('adminlte.restaurants'); ?></label>
                                      <br>
                                      <select style="width: 100%;" name="restaurants[]" class="form-control select2" required="" id="restaurants" multiple="">
                                        <option value="" disabled=""> -- </option>
                                        <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($r->id); ?>"> <?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="col-md-12 form-group">
                                      <label class="" for="remarks"> <?php echo app('translator')->getFromJson('adminlte.name'); ?> </label>
                                      <input type="text" name="name" placeholder="<?php echo app('translator')->getFromJson('adminlte.name'); ?>" class="form-control" required="">
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="col-md-12 form-group">
                                      <label class="" for="username"> <?php echo app('translator')->getFromJson('adminlte.username'); ?> </label>
                                      <input type="text" placeholder="<?php echo app('translator')->getFromJson('adminlte.username'); ?>" name="username" class="form-control" required="">
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="col-md-12 form-group">
                                      <label class="" for="email"> <?php echo app('translator')->getFromJson('adminlte.email'); ?> </label>
                                      <input type="email" name="email" placeholder="email" class="form-control" required="">
                                  </div>
                              </div>

                              <div class="row">
                                <div class="col-md-12 form-group">
                                    <label class="" for="password"> <?php echo app('translator')->getFromJson('adminlte.password_min'); ?> </label>
                                    <input type="password" minlength="8" name="password" class="form-control" placeholder="<?php echo app('translator')->getFromJson('adminlte.password'); ?>" required="">
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-md-12 form-group">
                                  <label class="txt1" for="password_confirmation"><?php echo app('translator')->getFromJson('adminlte.confirm_password'); ?></label>
                                  <input type="password" name="password_confirmation" class="form-control" minlength="8" placeholder="<?php echo app('translator')->getFromJson('adminlte.confirm_password'); ?>"required="" />
                                </div>
                              </div>

                              <div class="row">
                                <div class="form-group col-lg-12">
                                  <button style="float: right" type="submit" class="btn btn-success"><?php echo app('translator')->getFromJson('adminlte.submit'); ?></button>
                                  <a style="float: right; margin-right: 5px" href="#" data-dismiss="modal" class="btn btn-primary"><?php echo app('translator')->getFromJson('adminlte.cancel'); ?></a>
                                </div>
                              </div>

                          </form>

                      </div>

                  </div>

              </div>

          </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="updateModal">
    <div class="modal-dialog">

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal" aria-label="Close">

            <span aria-hidden="true">&times;</span></button>

          <h4 class="modal-title"><?php echo app('translator')->getFromJson('adminlte.sub_admin'); ?> | <?php echo app('translator')->getFromJson('adminlte.restaurant'); ?></h4>

        </div>

        <div class="modal-body" id="model_body">
        </div>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
  <script type="text/javascript">
    function LinksModal(user_id)
    {
      var data= {'user_id':user_id, '_token':'<?php echo e(csrf_token()); ?>' };

      $.post('<?php echo e(route('edit_account_status_modal')); ?>', data , function(response) {

          $("#model_body").html(response);
          $('#updateModal').modal('show');
      });
    }
  </script>

  <script type="text/javascript">
      $(document).ready(function() {
        // $('.select2').select2();
        // $('#restaurants_update').select2();
        $('select:not(.normal)').each(function () {
                $(this).select2({
                    dropdownParent: $(this).parent()
                });
            });
      });


  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>