<?php $__env->startSection('htmlheader_title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-styles'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>
  <div class="row">
    <div class="col-md-7">
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">
            Driver Information
          </h3>
        </div>
        <div class="box-body">
          <table class="table table-bordered">
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.actions'); ?></th>
              <td>
                <?php if($data->active == 1): ?>
                  Enabled &nbsp;
                  <a href="<?php echo e(route('toggle_account_status', encrypt($data->id))); ?>" class="btn btn-danger btn-sm">Disable</a>
                <?php else: ?>
                  Disabled &nbsp;
                  <a href="<?php echo e(route('toggle_account_status', encrypt($data->id))); ?>" class="btn btn-success btn-sm">Enable</a>
                <?php endif; ?>

                <a href="<?php echo e(route('edit_driver', encrypt($data->id))); ?>" class="btn btn-warning btn-sm pull-right"><?php echo app('translator')->getFromJson('adminlte.update'); ?></a>
              </td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.name'); ?></th>
              <td><?php echo e($data->name); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.phone_number'); ?></th>
              <td><?php echo e($data->mobile_no); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.citizen_type'); ?></th>
              <td><?php echo e($data->citizen_type); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.is_driver_online'); ?></th>
              <td>
                <?php if($data->is_driver_online == 1): ?>
                  <label class="label label-success"> Yes </label>
                <?php else: ?>
                  <label class="label label-danger"> No </label>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.is_driver_busy'); ?></th>
              <td>
                <?php if($data->is_driver_busy == 1): ?>
                  <label class="label label-success"> Yes </label>
                <?php else: ?>
                  <label class="label label-danger"> No </label>
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.current_latitude'); ?></th>
              <td>
                <?php if($data->is_driver_online == 1): ?>
                  <?php echo e($data->current_lat); ?>

                <?php else: ?>
                  ---
                <?php endif; ?>

              </td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.current_longitude'); ?></th>
              <td>
                <?php if($data->is_driver_online == 1): ?>
                  <?php echo e($data->current_lang); ?>

                <?php else: ?>
                  ---
                <?php endif; ?>
              </td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.city'); ?></th>
              <td><?php echo e($data->city); ?></td>
            </tr>
            <tr>
              <th>Machine Number</th>
              <td><?php echo e($data->machine_number); ?></td>
            </tr>
            
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="box box-danger" style="margin-bottom: 5px;">
        <div class="box-header">
          <h3 class="box-title">Account Information</h3>
        </div>
        <div class="box-body " style="padding: 0;">
          <table class="table">
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.username'); ?></th>
              <td><?php echo e($data->username); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.email'); ?></th>
              <td><?php echo e($data->email); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.email_status'); ?></th>
              <td><?php echo e(($data->verified == 1)? 'Verified': 'Unverified'); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.account_status'); ?></th>
              <td><?php echo e(($data->active == 1)? 'Active': 'Inactive'); ?></td>
            </tr>
            <tr>
              <th>Date of Joining</th>
              <td><?php echo e(date('d-m-Y', strtotime($data->created_at))); ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="box box-primary">
        <div class="box-header">
          <h3 class="box-title">Driver Statistics</h3>
        </div>
        <div class="box-body">
          <table class="table table-bordered">
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.total_delivered_orders'); ?></th>
              <td><?php echo e($data->statistics->total_orders); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.total_earnings'); ?></th>
              <td>SAR <?php echo e(number_format($data->statistics->total_delivery_fee, 2)); ?></td>
            </tr>
            <!-- <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.total_order_amount'); ?></th>
              <td>SAR <?php echo e(number_format($data->statistics->total_order_amount, 2)); ?></td>
            </tr>
            <tr>
              <th><?php echo app('translator')->getFromJson('adminlte.grand_total'); ?></th>
              <td>SAR <?php echo e(number_format($data->statistics->total_grand_amount, 2)); ?></td>
            </tr> -->
            <tr>
              <th>Wallet</th>
              <td>SAR <?php echo e(number_format($data->wallet, 2)); ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>

  <?php if($order != null): ?>
    <div class="row">
      <div class="col-md-12">
        <div class="box box-info" style="margin-bottom: 5px;">
          <div class="box-header">
            <h3 class="box-title">Order Details</h3>
          </div>
          <div class="box-body " style="padding: 0;">
            <table class="table">
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.active_order_id'); ?></th>
                <td>
                  <?php echo e($data->active_order_id); ?>

                </td>
              </tr>
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.restaurant_name'); ?></th>
                <td><?php echo e($order->restaurant_name); ?></td>
              </tr>
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.pickup_location'); ?></th>
                <td><?php echo e($order->pickup_address); ?></td>
              </tr>
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.dropoff_location'); ?></th>
                <td><?php echo e($order->dropoff_address); ?></td>
              </tr>
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.total_distance'); ?></th>
                <td><?php echo e($order->distance); ?></td>
              </tr>
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.order_amount'); ?></th>
                <td>SAR <?php echo e($order->order_amount); ?></td>
              </tr>
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.delivery_fee'); ?></th>
                <td>SAR <?php echo e($order->delivery_fee); ?></td>
              </tr>
              <tr>
                <th><?php echo app('translator')->getFromJson('adminlte.grand_total'); ?></th>
                <td>SAR <?php echo e($order->grand_total); ?></td>
              </tr>

            </table>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
  <!-- <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-body table-responsive">

        </div>
      </div>
    </div>
  </div> -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>

  <script type="text/javascript">
      $(document).ready(function() {

      });
  </script>



<?php $__env->stopPush(); ?>


<?php echo $__env->make('adminlte.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>