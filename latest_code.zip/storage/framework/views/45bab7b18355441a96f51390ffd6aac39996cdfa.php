<?php $__env->startSection('htmlheader_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('plugin-styles'); ?>
  <style type="text/css">
    .my_row{
      margin-left: 0 !important;
      margin-right: 0 !important;
    }
  </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

	  <div class="box">

      <div class="box-header">

      </div>

      <!-- /.box-header -->

      <div class="box-body">
        <div class="my_row">
          <?php if(session('status')): ?>
            <div class="alert alert-success">
              <?php echo e(session('status')); ?>

            </div>
          <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>
        </div>
        <div class="table-responsive">
          <table id="mydatatable" class="table table-bordered table-striped">

            <thead>

              <tr>

                <th><?php echo app('translator')->getFromJson('adminlte.serial_no'); ?></th>

                <?php if(auth()->user()->isAdmin == 1): ?>
                  <th><?php echo app('translator')->getFromJson('adminlte.restaurant'); ?></th>
                <?php endif; ?>

                <th><?php echo app('translator')->getFromJson('adminlte.customer_name'); ?> </th>

                <th><?php echo app('translator')->getFromJson('adminlte.customer_number'); ?></th>

                <!-- <th><?php echo app('translator')->getFromJson('adminlte.customer_address'); ?></th> -->

                <th><?php echo app('translator')->getFromJson('adminlte.pickup_location'); ?></th>

                <th><?php echo app('translator')->getFromJson('adminlte.dropoff_location'); ?></th>

                <th><?php echo app('translator')->getFromJson('adminlte.order_description'); ?></th>

                <!-- <th><?php echo app('translator')->getFromJson('adminlte.order_amount'); ?> </th> -->

                <th><?php echo app('translator')->getFromJson('adminlte.delivery_fee'); ?> </th>

                <th><?php echo app('translator')->getFromJson('adminlte.status'); ?></th>

                <th><?php echo app('translator')->getFromJson('adminlte.created_at'); ?></th>

                <th><?php echo app('translator')->getFromJson('adminlte.actions'); ?></th>

              </tr>

            </thead>

            <tbody>
              <?php if(count($data) > 0): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e(count($data) - $key); ?></td>

                    <?php if(auth()->user()->isAdmin == 1): ?>
                      <td><?php echo e($u->restaurant_name); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($u->customer_name); ?> </td>

                    <td><?php echo e($u->customer_number); ?></td>

                    <!-- <td><?php echo e($u->customer_address); ?></td> -->

                    <!-- <td><?php echo e($u->pickup_address); ?></td> -->
                    <td>
                      <?php echo e(\Illuminate\Support\Str::words($u->pickup_address, $words = 5, $end='...')); ?>

                    </td>

                    <!-- <td><?php echo e($u->dropoff_address); ?></td> -->
                    <td style="width:100px">
                      <?php echo e(\Illuminate\Support\Str::words($u->dropoff_address, $words = 5, $end='...')); ?>

                    </td>

                    <!-- <td><?php echo e($u->order_description); ?></td> -->

                    <td>
                      <?php echo e(\Illuminate\Support\Str::words($u->order_description, $words = 10, $end='...')); ?>

                    </td>

                    <!-- <td>SAR <?php echo e(number_format($u->order_amount, 2)); ?> </td> -->

                    <td>SAR <?php echo e(number_format($u->delivery_fee, 2)); ?> </td>
                    <td>

                      <?php if($u->status == 'Completed'): ?>
                        <span class="label label-success">
                          <?php echo app('translator')->getFromJson('adminlte.completed'); ?>
                        </span>
                      <?php elseif($u->status == 'Pending'): ?>
                        <span class="label label-warning">
                          <?php echo app('translator')->getFromJson('adminlte.pending'); ?>
                        </span>
                      <?php else: ?>
                        <span class="label label-info">
                          <?php echo e($u->status); ?>

                        </span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span hidden=""><?php echo e($u->created_at); ?></span>
                      <!-- <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($u->created_at))->diffForHumans()); ?> -->
                      <?php echo e(date('d-m-y', strtotime($u->created_at))); ?> &nbsp;
                      <?php echo e(date('g:i a', strtotime($u->created_at))); ?>

                    </td>

                    <td>
                      <a href="<?php echo e(route('order_details', encrypt($u->id) )); ?>" target="_blank"> <span class="label label-info"> <?php echo app('translator')->getFromJson('adminlte.view'); ?> </span></a>

                      <?php if($u->status == 'Pending'): ?>
                        <a href="<?php echo e(route('resend_order', $u->id )); ?>"> <span class="label label-primary"> <?php echo app('translator')->getFromJson('adminlte.resend_notification'); ?> </span></a>
                      <?php endif; ?>
                    </td>

                  </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <tr>
                  <td colspan="8">No order exists in db.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

      </div>

      <!-- /.box-body -->

    </div>

    <!-- /.box -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>